package com.area730.localnotif;

import android.util.Log;

/**
 * Created by Melnychenko on 9/5/2015.
 */
public class Logger {

    /**
     * Debug tag to filter output of this plugin
     */
    private static final String DEBUG_TAG       = "Area730Log";

    /**
     * Error messages start with this tag
     */
    private static final String ERROR_TAG       = "ERROR";

    /**
     * Warning messages start with this tag
     */
    private static final String WARNING_TAG     = "WARNING";

    /**
     * Info messages start with this tag
     */
    private static final String INFO_TAG        = "INFO";


    /**
     * Used to write log with plugin tag so you can easily filter plugin output
     * @param text Text that will be written to logcat with tag {@link Logger#DEBUG_TAG}
     */
    public  static  void Log(String text)
    {
        Log.d(Logger.DEBUG_TAG, text);
    }

    /**
     * Writes log with error tag {@link Logger#ERROR_TAG}
     * @param text Error text
     */
    public  static  void LogError(String text) { Log(ERROR_TAG + ": " + text); }

    /**
     * Writes log with warning tag {@link Logger#WARNING_TAG}
     * @param text Warning text
     */
    public  static  void LogWarning(String text) { Log(WARNING_TAG + ": " + text); }

    /**
     * Writed log with info tag {@link Logger#INFO_TAG}
     * @param text Info text
     */
    public  static  void LogInfo(String text) { Log(INFO_TAG + ": " + text); }

}
