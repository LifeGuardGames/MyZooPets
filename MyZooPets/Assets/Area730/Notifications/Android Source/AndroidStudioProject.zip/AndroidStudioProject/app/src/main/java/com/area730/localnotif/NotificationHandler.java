package com.area730.localnotif;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import static com.area730.localnotif.Logger.*;

import com.unity3d.player.UnityPlayer;

/**
 * Created by Vladyslav Melnychenko on 8/31/2015.
 */
public class NotificationHandler {

    /**
     * Handler is used so we can make function calls from UI thread.
     * as some elements must be called from UI thread (like toasts, notifications and other)
     */
    private static Handler UIHandler        = new Handler(Looper.getMainLooper());


    /**
     * Check plugin version
     * @return Current plugin version
     */
    public  static float getVersion() {
        return 1.3f;
    }


    //===========================================================================

    /**
     * Shows Android native toast
     * @param toastText Text to show on toast
     */
    public static void showToast(final String toastText) {
        LogInfo("NotificationHandler.showToast() call");
        UIHandler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(UnityPlayer.currentActivity, toastText, Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Schedules notification
     * @param delayMillis Delay in milliseconds when to show notification
     * @param id Notification id
     * @param title Notification title
     * @param body Notification text
     * @param ticker Text that is displayed in the status bar when the notification first arrives.
     * @param smallIcon Name of the resource for small icon (must be Drawable resource. If not specified or incorrect - application icon is used)
     * @param bigIcon Large icon that is shown in the ticker and notification.
     * @param defaults Default notification options that will be used.
     * @param autocancel etting this flag will make it so the notification is automatically canceled when the user clicks it in the panel
     * @param sound Sound resource name to play (must be in res/raw folder)
     * @param vibroPattern Vibration pattern to use.
     * @param when Time of the notification (used for sorting)
     * @param isRepeating Shows if this is a repeating notification or one-time
     * @param interval Interval of repetition for repeating notifications (in milliseconds)
     * @param number  Large number at the right-hand side of the notification.
     * @param alertOnce Set this flag if you would only like the sound, vibrate and ticker to be played if the notification is not already showing.
     * @param hexColor Sets color of the small icon background
     */
    public static void scheduleNotification(
            long delayMillis,
            int id,
            String title,
            String body,
            String ticker,
            String smallIcon,
            String bigIcon,
            int defaults,
            boolean autocancel,
            String sound,
            long [] vibroPattern,
            long when,
            boolean isRepeating,
            long interval,
            int number,
            boolean alertOnce,
            String hexColor)
    {
        Activity currentActivity = UnityPlayer.currentActivity;
        AlarmManager am = (AlarmManager)currentActivity.getSystemService(Context.ALARM_SERVICE);

        Intent intent = new Intent(currentActivity, NotificationReciever.class);
        intent.putExtra(NotificationReciever.TITLE_KEY, title);
        intent.putExtra(NotificationReciever.BODY_KEY, body);
        intent.putExtra(NotificationReciever.TICKER_KEY, ticker);
        intent.putExtra(NotificationReciever.ID_KEY, id);
        intent.putExtra(NotificationReciever.SMALL_ICON_KEY, smallIcon);
        intent.putExtra(NotificationReciever.BIG_ICON_KEY, bigIcon);
        intent.putExtra(NotificationReciever.DEFAULTS_KEY, defaults);
        intent.putExtra(NotificationReciever.AUTOCANCEL_KEY, autocancel);
        intent.putExtra(NotificationReciever.SOUND_KEY, sound);
        intent.putExtra(NotificationReciever.VIBRO_KEY, vibroPattern);
        intent.putExtra(NotificationReciever.WHEN_KEY, when);
        intent.putExtra(NotificationReciever.NUMBER_KEY, number);
        intent.putExtra(NotificationReciever.ALERT_ONCE_KEY, alertOnce);
        intent.putExtra(NotificationReciever.COLOR_KEY, hexColor);

        if (isRepeating) {
            if (interval != 0) {
                am.setRepeating(0, System.currentTimeMillis() + delayMillis, interval, PendingIntent.getBroadcast(currentActivity, id, intent, PendingIntent.FLAG_UPDATE_CURRENT));
                LogInfo("Repeating notification scheduled");
            } else {
                LogError("Notification not scheduled. You must specify the interval for repeating notification ( > 0)");
            }
        } else {
            am.set(0, System.currentTimeMillis() + delayMillis, PendingIntent.getBroadcast(currentActivity, id, intent, PendingIntent.FLAG_UPDATE_CURRENT));
            LogInfo("One time notification scheduled");
        }

    }

    /**
     * Cancels scheduled notification by id
     * @param id ID of the notification to cancel
     */
    public static void cancelNotifications(int id) {
        Activity currentActivity    = UnityPlayer.currentActivity;
        AlarmManager am             = (AlarmManager)currentActivity.getSystemService(Context.ALARM_SERVICE);
        Intent intent               = new Intent(currentActivity, NotificationReciever.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(currentActivity, id, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        am.cancel(pendingIntent);
        LogInfo("Notification with id " + id + " cancelled");
    }

    /**
     * Clears shown notification with specified id
     * @param id Id of the notification to cancel
     */
    public static void clear(int id) {
        Activity currentActivity                = UnityPlayer.currentActivity;
        NotificationManager notificationManager = (NotificationManager)currentActivity.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancel(id);
        LogInfo("Notification with id " + id + " cleared");
    }

    /**
     * Clears all shown notifications
     */
    public static void clearAll() {
        Activity currentActivity                = UnityPlayer.currentActivity;
        NotificationManager notificationManager = (NotificationManager)currentActivity.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancelAll();

        LogInfo("All notifications cleared");
    }

}
