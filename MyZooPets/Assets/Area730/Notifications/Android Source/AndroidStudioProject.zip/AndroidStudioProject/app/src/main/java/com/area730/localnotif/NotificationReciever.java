package com.area730.localnotif;


import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;

import com.unity3d.player.UnityPlayer;

import static com.area730.localnotif.Logger.*;

/**
 * Created by Vladyslav Melnychenko on 9/1/2015.
 */
public class NotificationReciever extends BroadcastReceiver {

    //================= STRING LITERALS ============================

    //=============== KEYS =================
    public static final String TITLE_KEY        = "title";
    public static final String BODY_KEY         = "body";
    public static final String TICKER_KEY       = "ticker";
    public static final String ID_KEY           = "id";
    public static final String SMALL_ICON_KEY   = "small_icon";
    public static final String BIG_ICON_KEY     = "big_icon";
    public static final String AUTOCANCEL_KEY   = "autocancel";
    public static final String SOUND_KEY        = "soundKey";
    public static final String WHEN_KEY         = "when";
    public static final String VIBRO_KEY        = "vibro";
    public static final String DEFAULTS_KEY     = "defaults";
    public static final String NUMBER_KEY       = "numberKey";
    public static final String ALERT_ONCE_KEY   = "alertOnce";
    public static final String COLOR_KEY        = "color";

    //=========== DEFAULT VALUES ===========

    private final String DEFAULT_TITLE          = "Default title";
    private final String DEFAULT_BODY           = "Default body";

    //======================================

    public static final String UNITY_CLASS      = "com.unity3d.player.UnityPlayerNativeActivity";
    public static final String DEFAULT_ICON     = "app_icon";
    public static final String DRAWABLE_TYPE    = "drawable";
    public static final String RAW_TYPE         = "raw";

    //===============================================================

    @Override
    public void onReceive(Context context, Intent intent) {
        LogInfo("NotificationReciever.onReceive(), package: " + context.getPackageName());

        //Extract data from intent
        String title        = intent.getStringExtra(TITLE_KEY);
        String body         = intent.getStringExtra(BODY_KEY);
        String smallIcon    = intent.getStringExtra(SMALL_ICON_KEY);
        String bigIcon      = intent.getStringExtra(BIG_ICON_KEY);
        String ticker       = intent.getStringExtra(TICKER_KEY);
        int id              = intent.getIntExtra(ID_KEY, 1);
        boolean autocancel  = intent.getBooleanExtra(AUTOCANCEL_KEY, false);
        String sound        = intent.getStringExtra(SOUND_KEY);
        long when           = intent.getLongExtra(WHEN_KEY, 0);
        long[] vibroPattern = intent.getLongArrayExtra(VIBRO_KEY);
        int defaults        = intent.getIntExtra(DEFAULTS_KEY, 0);
        int number          = intent.getIntExtra(NUMBER_KEY, 0);
        boolean alertOnce   = intent.getBooleanExtra(ALERT_ONCE_KEY, false);
        String hexColor     = intent.getStringExtra(COLOR_KEY);

        //=====================================================================

        //Class<?> unityClassActivity = UnityPlayer.currentActivity.getClass();

        Class<?> unityClassActivity = null;
        try {
            unityClassActivity = Class.forName(UNITY_CLASS);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        Resources res = context.getResources();
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(context);

        Intent notificationIntent           = new Intent(context, unityClassActivity);
        PendingIntent resultPendingIntent   = PendingIntent.getActivity(context, 0, notificationIntent, 0);

        // Find application icon. Is used as default small icon if user icon can't be found
        int defaultIconID = res.getIdentifier(DEFAULT_ICON, DRAWABLE_TYPE, context.getPackageName());


        // Basic settings

        // Required
        if (nullOrEmpty(title)) {
            title = DEFAULT_TITLE;
            LogWarning("Notification title is null or empty, Using default instead");
        }

        // Required
        if (nullOrEmpty(body)) {
            body = DEFAULT_BODY;
            LogWarning("Notification body is null or empty, Using default instead");
        }

        // Required
        if (nullOrEmpty(smallIcon)) {
            smallIcon = DEFAULT_ICON;
            LogWarning("Notification small icon name is null or empty, Using default instead");
        }

        // Check if small icon exists, otherwise use app's icon
        int smallIconRes = res.getIdentifier(smallIcon, DRAWABLE_TYPE, context.getPackageName());
        if (smallIconRes == 0) {
            smallIconRes = defaultIconID;
            LogWarning("Small icon (" + smallIcon + ") can't be found in " + DRAWABLE_TYPE + " folders. Using default icon instead");
        }

        // Build basic notification
        mBuilder
                .setContentTitle(title)
                .setContentText(body)
                .setSmallIcon(smallIconRes)
                .setAutoCancel(autocancel)
                .setOnlyAlertOnce(alertOnce)
                .setContentIntent(resultPendingIntent);



        // OPTIONAL SETTINGS

        if (!nullOrEmpty(ticker)) {
            mBuilder.setTicker(ticker);
        }

        if (vibroPattern != null) {
            mBuilder.setVibrate(vibroPattern);
        }

        if (when != 0) {
            mBuilder.setWhen(when);
        }

        if (defaults != 0) {
            mBuilder.setDefaults(defaults);
        }

        if (number != 0) {
            mBuilder.setNumber(number);
        }

        if (!nullOrEmpty(bigIcon)) {
            int bigIconRes = res.getIdentifier(bigIcon, DRAWABLE_TYPE, context.getPackageName());
            // Check if large icon resource was found
            if (bigIconRes == 0) {
                LogError("Large icon (" + bigIcon + ") can't be found in " + DRAWABLE_TYPE + " folders.");
            } else {
                mBuilder.setLargeIcon(BitmapFactory.decodeResource(res, bigIconRes));
            }
        }

        if (!nullOrEmpty(sound)) {
            int soundId = res.getIdentifier(sound, RAW_TYPE, context.getPackageName());
            // Check if sound resource was found
            if (soundId == 0) {
                LogError("Sound resource (" + sound + ") can't be found in " + RAW_TYPE + " folder");
            } else {
                Uri soundUri  = Uri.parse("android.resource://" + context.getPackageName() + "/" + soundId);
                mBuilder.setSound(soundUri);
            }
        }

        if (!nullOrEmpty(hexColor)) {
            try {
                int col = Color.parseColor(hexColor);
                mBuilder.setColor(col);
            } catch(IllegalArgumentException e) {
                LogError("Wrong color format");
            }
        }


        // Show notification
        NotificationManager notificationManager = (NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(id, mBuilder.build());
    }


    /**
     * Checks if string is null or empty
     * @param str String to check
     * @return true if the string is null or empty
     */
    private boolean nullOrEmpty(String str) {
        return !(str != null && !str.isEmpty());
    }

}
